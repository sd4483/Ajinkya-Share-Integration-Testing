package com.upgrad.testing;

import org.hamcrest.CoreMatchers;
import org.hamcrest.MatcherAssert;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class CalculatorTest {
    private Calculator calculator;
    // One assertion per unit test
    // Never share objects across test
    @BeforeEach
    void setUp() {
        calculator = new Calculator();
    }

    // Name should be self explanatory
    @Test
    void shouldReturnZeroForZeroInput() {
        // Arrange - Act - Assert or Given - When - Then
        // Act
        int result = calculator.add(0, 0);
        // Assert
        assertEquals(0, result);
        assertThat(result, is(0));
    }

    @Test
    void shouldReturnAdditionForPositiveNumbers() {
        // Arrange - Act - Assert or Given - When - Then

        int result = calculator.add(10, 20);

        assertThat(result, is(300));
    }

    @Test
    void shouldReturnAdditionForNegativeNumbers() {
        // Arrange - Act - Assert or Given - When - Then
        int expectedResult = -30;
        int actualResult = calculator.add(-10, -20);

        assertThat(actualResult, is(expectedResult));
    }

    @Test
    void shouldReturnAdditionForPositiveAndNegativeNumbers() {
        // Arrange - Act - Assert or Given - When - Then
        int expectedResult = 10;
        int actualResult = calculator.add(-10, 20);

        assertThat(actualResult, is(expectedResult));
    }

    @ParameterizedTest
    @CsvSource({"5,7,12", "5,-7,-2", "-5,7,2", "-5,-7,-12"})
    void shouldReturnAdditionForGivenNumbers(int a, int b, int expectedResult) {
        int result = calculator.add(a, b);
        // Assert - Then
        assertThat(result, is(expectedResult)); // 2
    }
}
